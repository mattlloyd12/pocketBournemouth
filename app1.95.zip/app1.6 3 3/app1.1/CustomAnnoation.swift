import MapKit

class CustomAnnotation: NSObject, MKAnnotation {
    
    var title: String?
    var coordinate: CLLocationCoordinate2D
    var region: CLCircularRegion!
    var info: String?
    
    init(coordinate: CLLocationCoordinate2D, title: String, info: String) {
        self.coordinate = coordinate
        self.title = title
        self.info = info
        region = CLCircularRegion(center: coordinate, radius: 100, identifier: title)
    }
    
}
