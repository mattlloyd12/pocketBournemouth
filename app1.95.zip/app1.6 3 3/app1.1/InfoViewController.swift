import Foundation
import UIKit

class InfoViewController: UIViewController {
    
    @IBOutlet weak var infoImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var infoLabel: UILabel!
    
    var annotation: CustomAnnotation!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = annotation.title!
        
        infoLabel.text = annotation.info!
        
    
    
    }
    
    
}
